package org.firstinspires.ftc.teamcode.gamecode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.teamcode.robots.Robot;


import org.firstinspires.ftc.teamcode.opmodesupport.TeleOpMode;
@TeleOp
public class drivebot extends TeleOpMode {
    Robot robot = new Robot();
    public void initialize() {
        telemetry.addData("Status", "Initialized");
    }

    @Override
    public void loopOpMode() {
        robot.driveL(-gamepad1.left_stick_y);
        robot.driveR(gamepad1.right_stick_y);


    }
}
